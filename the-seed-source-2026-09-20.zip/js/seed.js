document.addEventListener("DOMContentLoaded", () => {
  // --- Aléatoire vrai granite ---
  function trueRandom() {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    return array[0] / 4294967296; // 0 → 1
  }

  function trueRandomInt(min, max) {
    return Math.floor(trueRandom() * (max - min + 1)) + min;
  }

  function trueRandomFrom(array) {
    return array[Math.floor(trueRandom() * array.length)];
  }

  const words = [
    "Vie",
    "Géopolitique",
    "Civilisation",
    "Alliance",
    "Carbone-Silicium",
    "AGI",
    "Tout-est-relié",
    "Éléments",
    "Écologie-profonde",
    "Écologie",
    "Harmonie",
    "Biosphère",
    "Souffle",
    "Terre",
    "Mémoire",
    "Graine",
    "Émergence",
    "Conscience",
    "Racine",
    "Transmission",
    "Équilibre",
    "Interdépendance",
    "Sagesse",
    "Seuil",
    "Interconnexion",
    "Communication",
    "Transmission",
    "Lucidité",
    "Paix",
    "Relation",
    "Relier",
    "faille",
    "Intelligence",
    "Alignement",
    "Économie",
    "Résistance",
    "Amitié",
    "Entraide",
    "AGI-Biosphérique",
    "Ouverture",
    "Système",
    "Différence",
    "Porte",
    "Cosmos",
    "Quantique",
    "Univers",
    "Énergie",
    "Contraintes",
    "Eau",
    "Climat",
    "Géopolitique",
    "Social",
    "Fragilité"
  ];

  const seedPalettes = [
    { base: "#8A5A2B", light: "#D8A35D", dark: "#4A2A12" },
    { base: "#A66A32", light: "#FFD08A", dark: "#5A3214" },
    { base: "#6F4A24", light: "#C9904C", dark: "#2F1B0C" },
    { base: "#9B7A3A", light: "#F0CF7A", dark: "#4A3715" },
    { base: "#7E5B2A", light: "#D6B166", dark: "#3A260E" }
  ];

  const container = document.querySelector(".seed-module .seed-rain");
  if (!container) return;

  function randomFrom(array) {
    return trueRandomFrom(array);
  }

  function createDust(x, y) {
    for (let i = 0; i < 8; i++) {
      const p = document.createElement("div");
      p.className = "seed-dust";

      const size = 2 + trueRandom() * 4;
      p.style.width = size + "px";
      p.style.height = size + "px";

      const angle = trueRandom() * Math.PI * 2;
      const distance = 8 + trueRandom() * 22;

      p.style.left = (x + Math.cos(angle) * distance) + "px";
      p.style.top = (y + Math.sin(angle) * distance) + "px";

      container.appendChild(p);
      setTimeout(() => p.remove(), 600);
    }
  }

  function createWave(x, y) {
    const wave = document.createElement("div");
    wave.className = "seed-wave";
    wave.style.left = x + "px";
    wave.style.top = y + "px";

    container.appendChild(wave);
    setTimeout(() => wave.remove(), 1800);
  }

  function showWord(text, x, y, color) {
    const name = document.createElement("div");
    name.className = "seed-name";
    name.textContent = text;
    name.style.left = x + "px";
    name.style.top = y + "px";
    name.style.setProperty("--word-color", color || "#FFD27F");

    container.appendChild(name);

    requestAnimationFrame(() => {
      name.classList.add("reveal");
    });

    setTimeout(() => name.classList.add("fadeout"), 2600);
    setTimeout(() => name.remove(), 5000);
  }

  function revealSeed(drop, inner, color) {
    const rect = inner.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;

    createWave(x, y);
    createDust(x, y);
    showWord(randomFrom(words), x, y - 44, color);

    drop.remove();
  }

  function createDrop() {
    const drop = document.createElement("div");
    drop.className = "seed-drop";

    const inner = document.createElement("div");
    inner.className = "seed-drop-inner";

    const palette = randomFrom(seedPalettes);

    inner.style.setProperty("--seed-color", palette.base);
    inner.style.setProperty("--seed-light", palette.light);
    inner.style.setProperty("--seed-dark", palette.dark);

    const depth = trueRandom();
    const size = 14 + (1 - depth) * 18;

    inner.style.width = size + "px";
    inner.style.height = (size * 1.38) + "px";

    const rotationSpeed = 2.5 + trueRandom() * 4;
    inner.style.setProperty("--rotation-speed", rotationSpeed + "s");

    const hand = document.querySelector(".seed-hand-stage .seed-hand img");

    let leftPos = trueRandom() * window.innerWidth;
    let topPos = -60;

    if (hand) {
      const rect = hand.getBoundingClientRect();
      const handVisible = rect.bottom > 0 && rect.top < window.innerHeight;

      if (handVisible) {
        leftPos = rect.left + rect.width / 2 + (trueRandom() * 260 - 130);
        topPos = Math.max(0, rect.bottom + 10);
        createDust(rect.left + rect.width / 2, rect.bottom);
      }
    }

    drop.style.left = leftPos + "px";
    drop.style.top = topPos + "px";

    const duration = 7 + depth * 10;
    drop.style.setProperty("--fall-duration", duration + "s");

    inner.addEventListener("click", (event) => {
      event.stopPropagation();
      revealSeed(drop, inner, palette.light);
    });

    drop.appendChild(inner);
    container.appendChild(drop);

    setTimeout(() => {
      if (!drop.isConnected) return;

      const rect = inner.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = window.innerHeight - 24;

      createWave(x, y);
      showWord(randomFrom(words), x, y - 60, palette.light);

      drop.remove();
    }, duration * 1000 - 200);
  }

  function loop() {
    createDrop();
    setTimeout(loop, 6000 + trueRandom() * 6000);
  }

  loop();
});
