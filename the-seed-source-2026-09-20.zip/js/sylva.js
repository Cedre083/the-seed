(() => {
  'use strict';

  const STORAGE_KEY = 'sylva-mascotte-masquee';
  const root = document.querySelector('[data-sylva]');
  const opener = document.querySelector('[data-sylva-open]');
  if (!root) return;

  const scene = root.querySelector('.sylva-scene');
  const close = root.querySelector('.sylva-close');
  const menuToggle = root.querySelector('.sylva-menu-toggle');
  const bubble = root.querySelector('.sylva-bulle');
  const summaryButton = root.querySelector('[data-sylva-action="sommaire"]');
  const nextButton = root.querySelector('[data-sylva-action="suivant"]');
  const topButton = root.querySelector('[data-sylva-action="haut"]');
  const videoButton = root.querySelector('[data-sylva-action="video"]');
  const videoModal = document.querySelector('[data-sylva-video-modal]');
  const videoClose = videoModal?.querySelector('[data-sylva-video-close]');
  const video = videoModal?.querySelector('[data-sylva-video]');
  const poses = [...root.querySelectorAll('.sylva-pose')];
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let timer;
  let drag = null;
  let ignoreClick = false;
  let lookFrame = 0;
  let videoCloseTimer = 0;
  let videoReturnFocus = null;

  if (localStorage.getItem(STORAGE_KEY) === '1') {
    root.hidden = true;
    if (opener) opener.hidden = false;
  }

  function showPose(name, duration = 0) {
    clearTimeout(timer);
    const target = poses.find((pose) => pose.dataset.pose === name);
    if (!target) return;
    if (!target.src && target.dataset.src) {
      target.src = target.dataset.src;
      target.removeAttribute('data-src');
    }
    poses.forEach((pose) => pose.classList.toggle('is-active', pose === target));

    if (duration) {
      timer = window.setTimeout(() => showPose('repos'), duration);
    }
  }

  function toggleActions() {
    showPose('salut', 2300);
    updateBubblePlacement();
    summaryButton.hidden = !findSummary();
    nextButton.hidden = !findNextHeading();
    bubble.classList.toggle('is-visible');
    menuToggle?.setAttribute('aria-expanded', bubble.classList.contains('is-visible') ? 'true' : 'false');
  }

  scene.addEventListener('click', () => {
    if (ignoreClick) {
      ignoreClick = false;
      return;
    }
    toggleActions();
  });

  menuToggle?.addEventListener('click', (event) => {
    event.stopPropagation();
    toggleActions();
  });

  document.addEventListener('click', (event) => {
    if (!bubble.classList.contains('is-visible')) return;
    if (root.contains(event.target)) return;
    bubble.classList.remove('is-visible');
    menuToggle?.setAttribute('aria-expanded', 'false');
    showPose('repos');
  });

  function openVideo() {
    if (!videoModal || !video) return;
    window.clearTimeout(videoCloseTimer);
    videoReturnFocus = document.activeElement;
    bubble.classList.remove('is-visible');
    menuToggle?.setAttribute('aria-expanded', 'false');
    showPose('curiosite', 2200);
    videoModal.hidden = false;
    document.body.classList.add('sylva-video-open');
    requestAnimationFrame(() => {
      videoModal.classList.add('is-visible');
      videoClose?.focus();
      video.play().catch(() => { /* Les commandes restent disponibles si la lecture automatique est bloquée. */ });
    });
  }

  function closeVideo() {
    if (!videoModal || videoModal.hidden) return;
    video.pause();
    video.currentTime = 0;
    videoModal.classList.remove('is-visible');
    document.body.classList.remove('sylva-video-open');

    const finish = () => {
      videoModal.hidden = true;
      if (videoReturnFocus instanceof HTMLElement) videoReturnFocus.focus();
      videoReturnFocus = null;
    };

    if (reduceMotion) finish();
    else videoCloseTimer = window.setTimeout(finish, 260);
  }

  videoButton?.addEventListener('click', openVideo);
  videoClose?.addEventListener('click', closeVideo);
  videoModal?.addEventListener('click', (event) => {
    if (event.target === videoModal) closeVideo();
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && videoModal && !videoModal.hidden) {
      closeVideo();
      return;
    }

    if (event.key === 'Tab' && videoModal && !videoModal.hidden) {
      const controls = [...videoModal.querySelectorAll('button, video, [href], [tabindex]:not([tabindex="-1"])')]
        .filter((element) => !element.hasAttribute('disabled'));
      if (controls.length) {
        const first = controls[0];
        const last = controls[controls.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
      return;
    }

    if (event.key !== 'Escape' || !bubble.classList.contains('is-visible')) return;
    bubble.classList.remove('is-visible');
    menuToggle?.setAttribute('aria-expanded', 'false');
    showPose('repos');
    scene.focus();
  });

  scene.addEventListener('mouseenter', () => {
    if (!reduceMotion) showPose('curiosite', 1800);
  });

  scene.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      scene.click();
    }
  });

  close.addEventListener('click', (event) => {
    event.stopPropagation();
    bubble.classList.remove('is-visible');
    menuToggle?.setAttribute('aria-expanded', 'false');
    root.hidden = true;
    if (opener) opener.hidden = false;
    localStorage.setItem(STORAGE_KEY, '1');
  });

  opener?.addEventListener('click', () => {
    root.hidden = false;
    opener.hidden = true;
    localStorage.removeItem(STORAGE_KEY);
    updateBubblePlacement();
    showPose('salut', 1800);
  });

  function findSummary() {
    return document.querySelector('#sommaire, #summary, [data-sommaire], nav[aria-label*="ommaire"]');
  }

  function findNextHeading() {
    const header = document.getElementById('header');
    const headerHeight = header ? header.getBoundingClientRect().height : 0;
    const gap = matchMedia('(max-width: 48rem)').matches ? 8 : 12;
    const currentLimit = window.scrollY + headerHeight + gap + 24;

    return [...document.querySelectorAll('main h2, main h3, article h2, article h3')]
      .find((heading) => heading.getBoundingClientRect().top + window.scrollY > currentLimit);
  }

  function goTo(target, hash = '', keepMenuOpen = false) {
    if (!target) return;
    const header = document.getElementById('header');
    const headerHeight = header ? header.getBoundingClientRect().height : 0;
    const gap = matchMedia('(max-width: 48rem)').matches ? 8 : 12;
    const top = target.getBoundingClientRect().top + window.scrollY - headerHeight - gap;

    window.scrollTo({
      top: Math.max(0, top),
      behavior: reduceMotion ? 'auto' : 'smooth'
    });

    if (hash && history.replaceState) history.replaceState(null, '', hash);
    if (!keepMenuOpen) {
      bubble.classList.remove('is-visible');
      menuToggle?.setAttribute('aria-expanded', 'false');
    }
    showPose('curiosite', 1600);
  }

  const summary = findSummary();
  summaryButton.hidden = !summary;
  summaryButton.addEventListener('click', () => goTo(findSummary(), '#sommaire'));
  nextButton.addEventListener('click', () => {
    const nextHeading = findNextHeading();
    if (!nextHeading) {
      nextButton.hidden = true;
      return;
    }

    nextButton.disabled = true;
    goTo(nextHeading, '', true);

    window.setTimeout(() => {
      nextButton.disabled = false;
      nextButton.hidden = !findNextHeading();
    }, reduceMotion ? 50 : 650);
  });
  topButton.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
    bubble.classList.remove('is-visible');
    menuToggle?.setAttribute('aria-expanded', 'false');
    showPose('salut', 1600);
  });

  function clampPosition(x, y) {
    const rect = root.getBoundingClientRect();
    return {
      x: Math.min(Math.max(6, x), innerWidth - rect.width - 6),
      y: Math.min(Math.max(6, y), innerHeight - rect.height - 6)
    };
  }

  function updateBubblePlacement() {
    const rect = root.getBoundingClientRect();
    bubble.classList.toggle('is-right', rect.left + rect.width / 2 < innerWidth / 2);
    bubble.classList.toggle('is-below', rect.top < 190);
  }

  function applyPosition(x, y, save = false) {
    const position = clampPosition(x, y);
    root.style.left = `${position.x}px`;
    root.style.top = `${position.y}px`;
    root.style.right = 'auto';
    root.style.bottom = 'auto';
    updateBubblePlacement();
    if (save) localStorage.setItem('sylva-mascotte-position', JSON.stringify(position));
  }

  try {
    const saved = JSON.parse(localStorage.getItem('sylva-mascotte-position'));
    if (Number.isFinite(saved?.x) && Number.isFinite(saved?.y)) applyPosition(saved.x, saved.y);
  } catch (_) { /* Position invalide : conserver l'emplacement par défaut. */ }

  scene.addEventListener('pointerdown', (event) => {
    const rect = root.getBoundingClientRect();
    const threshold = event.pointerType === 'touch' ? 16 : event.pointerType === 'pen' ? 9 : 5;
    drag = { id: event.pointerId, dx: event.clientX - rect.left, dy: event.clientY - rect.top, startX: event.clientX, startY: event.clientY, threshold };
    scene.setPointerCapture(event.pointerId);
  });

  scene.addEventListener('pointermove', (event) => {
    if (!drag || drag.id !== event.pointerId) return;
    const distance = Math.hypot(event.clientX - drag.startX, event.clientY - drag.startY);
    if (distance > drag.threshold) {
      ignoreClick = true;
      bubble.classList.remove('is-visible');
      menuToggle?.setAttribute('aria-expanded', 'false');
      applyPosition(event.clientX - drag.dx, event.clientY - drag.dy);
    }
  });

  scene.addEventListener('pointerup', (event) => {
    if (!drag || drag.id !== event.pointerId) return;
    const rect = root.getBoundingClientRect();
    if (ignoreClick) applyPosition(rect.left, rect.top, true);
    drag = null;
  });

  window.addEventListener('resize', () => {
    if (root.style.left) applyPosition(root.getBoundingClientRect().left, root.getBoundingClientRect().top);
    updateBubblePlacement();
  });

  if (!reduceMotion) {
    document.addEventListener('pointermove', (event) => {
      if (drag || lookFrame) return;
      lookFrame = requestAnimationFrame(() => {
        const rect = root.getBoundingClientRect();
        const dx = Math.max(-1, Math.min(1, (event.clientX - (rect.left + rect.width / 2)) / (innerWidth / 2)));
        const dy = Math.max(-1, Math.min(1, (event.clientY - (rect.top + rect.height * .3)) / (innerHeight / 2)));
        root.style.setProperty('--sylva-look-x', `${(dx * 2.2).toFixed(2)}px`);
        root.style.setProperty('--sylva-look-y', `${(dy * 1.4).toFixed(2)}px`);
        root.style.setProperty('--sylva-look-r', `${(dx * 1.7).toFixed(2)}deg`);
        lookFrame = 0;
      });
    }, { passive: true });
  }

  updateBubblePlacement();

  if (!reduceMotion) {
    window.setInterval(() => {
      if (!document.hidden && !root.hidden && !bubble.classList.contains('is-visible')) showPose('curiosite', 2100);
    }, 14000);
  }
})();
