(function () {
  'use strict';

  const isEnglish = (document.documentElement.lang || '').toLowerCase().startsWith('en') || location.pathname.startsWith('/en/');

  const D = {
    'biosphere': {
      fr: ['Biosphère', 'Ensemble des êtres vivants, des milieux où la vie existe sur Terre et de toutes leurs interactions.', 'https://fr.wikipedia.org/wiki/Biosph%C3%A8re'],
      en: ['Biosphere', 'The global system formed by all living beings, the environments where life exists on Earth, and their interactions.', 'https://en.wikipedia.org/wiki/Biosphere']
    },
    'biodiversity': {
      fr: ['Biodiversité', 'Diversité du vivant à plusieurs niveaux : gènes, espèces, écosystèmes et relations entre eux.', 'https://fr.wikipedia.org/wiki/Biodiversit%C3%A9'],
      en: ['Biodiversity', 'The variety of life at several levels, including genes, species, ecosystems and the relationships among them.', 'https://en.wikipedia.org/wiki/Biodiversity']
    },
    'climate-change': {
      fr: ['Changement climatique', 'Modification durable du climat. Le réchauffement actuel est principalement dû aux émissions humaines de gaz à effet de serre.', 'https://fr.wikipedia.org/wiki/Changement_climatique'],
      en: ['Climate change', 'Long-term change in climate. Present-day warming is mainly driven by human greenhouse-gas emissions.', 'https://en.wikipedia.org/wiki/Climate_change']
    },
    'artificial-intelligence': {
      fr: ['Intelligence artificielle', 'Ensemble de méthodes informatiques permettant à des systèmes d’accomplir des tâches associées à certaines capacités humaines : perception, langage, raisonnement ou décision.', 'https://fr.wikipedia.org/wiki/Intelligence_artificielle'],
      en: ['Artificial intelligence', 'Computer methods that enable systems to perform tasks associated with human abilities such as perception, language, reasoning or decision-making.', 'https://en.wikipedia.org/wiki/Artificial_intelligence']
    },
    'agi': {
      fr: ['Intelligence artificielle générale (AGI)', 'Concept d’une intelligence artificielle capable de généraliser ses apprentissages et d’accomplir un large éventail de tâches intellectuelles, au-delà d’un domaine spécialisé.', 'https://fr.wikipedia.org/wiki/Intelligence_artificielle_g%C3%A9n%C3%A9rale'],
      en: ['Artificial general intelligence (AGI)', 'The proposed form of AI able to generalize learning and perform a broad range of intellectual tasks rather than remain limited to one specialized domain.', 'https://en.wikipedia.org/wiki/Artificial_general_intelligence']
    },
    'agi-biospheric': {
      fr: ['AGI biosphérique', 'Approche défendue par The Seed et AGIBiospheric : une intelligence générale qui intègre explicitement les dépendances du vivant, les contraintes physiques de la Terre et les conséquences de ses décisions sur la biosphère.', 'https://agibiospheric.net/'],
      en: ['Biospheric AGI', 'An approach developed by The Seed and AGIBiospheric: general intelligence that explicitly incorporates living-system dependencies, Earth’s physical constraints and the biospheric consequences of its decisions.', 'https://agibiospheric.net/en/']
    },
    'interdependence': {
      fr: ['Interdépendance', 'Situation dans laquelle plusieurs éléments dépendent les uns des autres : une modification de l’un peut produire des effets en chaîne sur les autres.', 'https://fr.wikipedia.org/wiki/Interd%C3%A9pendance'],
      en: ['Interdependence', 'A relationship in which several elements depend on one another, so a change in one can propagate effects through the others.', 'https://en.wikipedia.org/wiki/Interdependence']
    },
    'planetary-boundaries': {
      fr: ['Limites planétaires', 'Cadre scientifique décrivant plusieurs grands processus du système Terre et les zones dans lesquelles les sociétés humaines peuvent évoluer avec un risque moindre de déstabilisation planétaire.', 'https://www.stockholmresilience.org/research/planetary-boundaries.html'],
      en: ['Planetary boundaries', 'A scientific framework describing major Earth-system processes and the zones within which human societies can operate with lower risk of destabilizing the planet.', 'https://www.stockholmresilience.org/research/planetary-boundaries.html']
    },
    'critical-infrastructure': {
      fr: ['Infrastructure critique', 'Installation, réseau ou service essentiel dont l’interruption grave peut affecter la sécurité, la santé, l’économie ou le fonctionnement de la société.', 'https://fr.wikipedia.org/wiki/Infrastructure_critique'],
      en: ['Critical infrastructure', 'Essential facilities, networks or services whose serious disruption can affect security, health, the economy or the functioning of society.', 'https://en.wikipedia.org/wiki/Critical_infrastructure']
    },
    'hybrid-warfare': {
      fr: ['Guerre hybride', 'Combinaison coordonnée de moyens militaires et non militaires : cyberattaques, désinformation, sabotage, coercition économique ou opérations clandestines.', 'https://fr.wikipedia.org/wiki/Guerre_hybride'],
      en: ['Hybrid warfare', 'Coordinated use of military and non-military means such as cyberattacks, disinformation, sabotage, economic pressure or covert operations.', 'https://en.wikipedia.org/wiki/Hybrid_warfare']
    },
    'disinformation': {
      fr: ['Désinformation', 'Diffusion intentionnelle d’informations fausses ou trompeuses afin d’influencer des perceptions, des décisions ou des comportements.', 'https://fr.wikipedia.org/wiki/D%C3%A9sinformation'],
      en: ['Disinformation', 'Deliberate dissemination of false or misleading information intended to influence perceptions, decisions or behaviour.', 'https://en.wikipedia.org/wiki/Disinformation']
    },
    'cyberattaques': {
  fr: [
    'Cyberattaques',
    'Actions malveillantes menées à l’aide de systèmes informatiques ou de réseaux afin de perturber, espionner, détruire ou compromettre des données, des services ou des infrastructures.',
    'https://fr.wikipedia.org/wiki/Cyberattaque'
  ],
  en: [
    'Cyberattacks',
    'Malicious actions carried out through computer systems or networks to disrupt, spy on, destroy or compromise data, services or infrastructure.',
    'https://en.wikipedia.org/wiki/Cyberattack'
  ]
},
    'intrication': {
  fr: [
    'Intrication quantique',
    'Phénomène physique dans lequel plusieurs systèmes quantiques partagent un état corrélé, de sorte que leurs propriétés ne peuvent pas être décrites indépendamment les unes des autres.',
    'https://fr.wikipedia.org/wiki/Intrication_quantique'
  ],
  en: [
    'Quantum entanglement',
    'A physical phenomenon in which multiple quantum systems share a correlated state, so that their properties cannot be described independently of one another.',
    'https://en.wikipedia.org/wiki/Quantum_entanglement'
  ]
},
    'resilience': {
      fr: ['Résilience', 'Capacité d’un système à absorber une perturbation, continuer à fonctionner ou se réorganiser sans perdre ses fonctions essentielles.', 'https://fr.wikipedia.org/wiki/R%C3%A9silience_%C3%A9cologique'],
      en: ['Resilience', 'The capacity of a system to absorb disturbance, keep functioning or reorganize without losing its essential functions.', 'https://en.wikipedia.org/wiki/Ecological_resilience']
    },
    'complex-system': {
      fr: ['Système complexe', 'Ensemble composé de nombreux éléments en interaction dont le comportement global ne se réduit pas simplement à la somme de ses parties.', 'https://fr.wikipedia.org/wiki/Syst%C3%A8me_complexe'],
      en: ['Complex system', 'A system made of many interacting parts whose overall behaviour cannot be understood simply by adding up the behaviour of each part.', 'https://en.wikipedia.org/wiki/Complex_system']
    },
    'geopolitics': {
      fr: ['Géopolitique', 'Étude des rapports de pouvoir entre territoires, États, ressources, populations et espaces stratégiques.', 'https://fr.wikipedia.org/wiki/G%C3%A9opolitique'],
      en: ['Geopolitics', 'The study of power relationships involving territories, states, resources, populations and strategic spaces.', 'https://en.wikipedia.org/wiki/Geopolitics']
    },
    'transhumanisme': {
  fr: [
    'Transhumanisme',
    'Courant de pensée visant à transformer la condition humaine par les technologies, en améliorant les capacités physiques, cognitives ou psychiques.',
    'https://fr.wikipedia.org/wiki/Transhumanisme'
  ],
  en: [
    'Transhumanism',
    'A movement aiming to transform the human condition through technologies that enhance physical, cognitive, or psychological capacities.',
    'https://en.wikipedia.org/wiki/Transhumanism'
  ]
},
    'ecosystem': {
      fr: ['Écosystème', 'Ensemble formé par une communauté d’êtres vivants, son milieu physique et toutes les interactions qui les relient.', 'https://fr.wikipedia.org/wiki/%C3%89cosyst%C3%A8me'],
      en: ['Ecosystem', 'A community of living organisms together with its physical environment and the interactions connecting them.', 'https://en.wikipedia.org/wiki/Ecosystem']
    },
    'anoxygenic-photosynthesis': {
      fr: ['Photosynthèse anoxygénique', 'Forme de photosynthèse qui utilise la lumière sans produire d’oxygène, pratiquée notamment par certaines bactéries.', 'https://fr.wikipedia.org/wiki/Photosynth%C3%A8se_anoxyg%C3%A9nique'],
      en: ['Anoxygenic photosynthesis', 'A form of photosynthesis that uses light without producing oxygen, carried out by several groups of bacteria.', 'https://en.wikipedia.org/wiki/Anoxygenic_photosynthesis']
    },
    'orange-dwarf': {
      fr: ['Naine orange', 'Étoile de la séquence principale de type spectral K, moins chaude et généralement moins massive que le Soleil.', 'https://fr.wikipedia.org/wiki/Naine_orange'],
      en: ['Orange dwarf', 'A K-type main-sequence star, cooler and generally less massive than the Sun.', 'https://en.wikipedia.org/wiki/K-type_main-sequence_star']
    },
    'light-year': {
      fr: ['Année-lumière', 'Unité de distance correspondant à ce que la lumière parcourt dans le vide en une année, soit environ 9 460 milliards de kilomètres.', 'https://fr.wikipedia.org/wiki/Ann%C3%A9e-lumi%C3%A8re'],
      en: ['Light-year', 'A unit of distance equal to how far light travels through a vacuum in one year, about 9.46 trillion kilometres.', 'https://en.wikipedia.org/wiki/Light-year']
    },
    'symbiosis': {
      fr: ['Symbiose', 'Association biologique étroite et durable entre des organismes d’espèces différentes.', 'https://fr.wikipedia.org/wiki/Symbiose'],
      en: ['Symbiosis', 'A close and persistent biological interaction between organisms of different species.', 'https://en.wikipedia.org/wiki/Symbiosis']
    },
    'cyberattack': {
      fr: ['Cyberattaque', 'Action malveillante visant un système informatique, un réseau ou des données afin de perturber, espionner, altérer ou détruire.', 'https://fr.wikipedia.org/wiki/Cyberattaque'],
      en: ['Cyberattack', 'A malicious action targeting computer systems, networks or data in order to disrupt, spy, alter or destroy.', 'https://en.wikipedia.org/wiki/Cyberattack']
    },
    'tipping-point': {
      fr: ['Point de basculement', 'Seuil à partir duquel une petite modification supplémentaire peut entraîner un changement important et parfois difficilement réversible du système.', 'https://fr.wikipedia.org/wiki/Point_de_basculement'],
      en: ['Tipping point', 'A threshold beyond which a small additional change can trigger a large and sometimes difficult-to-reverse shift in a system.', 'https://en.wikipedia.org/wiki/Tipping_point_(climatology)']
    },
    'homo-sapiens': {
  fr: [
    'Homo sapiens',
    'Espèce humaine actuelle. Homo sapiens appartient au genre Homo et à la famille des Hominidés.',
    'https://fr.wikipedia.org/wiki/Homo_sapiens'
  ],
  en: [
    'Homo sapiens',
    'The living human species, belonging to the genus Homo and the family Hominidae.',
    'https://en.wikipedia.org/wiki/Human'
  ]
},
    'indigenous-south-america': {
      fr: ['Peuples autochtones d’Amérique du Sud', 'Ensemble très divers de peuples et de cultures autochtones du continent sud-américain, notamment en Amazonie.', 'https://fr.wikipedia.org/wiki/Peuples_indig%C3%A8nes_d%27Am%C3%A9rique_du_Sud'],
      en: ['Indigenous peoples of South America', 'The highly diverse Indigenous peoples and cultures of the South American continent, including those of the Amazon basin.', 'https://en.wikipedia.org/wiki/Indigenous_peoples_of_South_America']
    },
    'cacocracy': {
      fr: ['Cacocratie / kakistocratie', 'Forme de gouvernement dans laquelle le pouvoir est exercé par les personnes considérées comme les moins compétentes, les plus médiocres ou les plus corrompues.', 'https://fr.wikipedia.org/wiki/Cacocratie'],
      en: ['Kakistocracy', 'Government by people considered among the least qualified, least competent or most corrupt.', 'https://en.wikipedia.org/wiki/Kakistocracy']
    },
    'kepler-442': {
      fr: ['Kepler-442', 'Étoile de type K située dans la constellation de la Lyre. L’exoplanète Kepler-442 b orbite dans sa zone habitable estimée.', 'https://fr.wikipedia.org/wiki/Kepler-442'],
      en: ['Kepler-442', 'A K-type star in the constellation Lyra. The exoplanet Kepler-442 b orbits within its estimated habitable zone.', 'https://en.wikipedia.org/wiki/Kepler-442']
    },
    'nuclear-weapon': {
      fr: ['Arme nucléaire', 'Arme dont l’énergie explosive provient de réactions nucléaires de fission, de fusion, ou d’une combinaison des deux.', 'https://fr.wikipedia.org/wiki/Arme_nucl%C3%A9aire'],
      en: ['Nuclear weapon', 'A weapon whose explosive energy comes from nuclear fission, fusion, or a combination of both.', 'https://en.wikipedia.org/wiki/Nuclear_weapon']
    },
    'bios-computing': {
      fr: ['BIOS (informatique)', 'Micrologiciel de démarrage historiquement chargé d’initialiser le matériel d’un ordinateur et de lancer le processus de démarrage du système.', 'https://fr.wikipedia.org/wiki/BIOS_(informatique)'],
      en: ['BIOS', 'Firmware historically responsible for initializing computer hardware and beginning the system boot process.', 'https://en.wikipedia.org/wiki/BIOS']
    },
    'tim-berners-lee': {
      fr: ['Tim Berners-Lee', 'Informaticien britannique à l’origine du World Wide Web, qu’il a proposé au CERN à la fin des années 1980.', 'https://fr.wikipedia.org/wiki/Tim_Berners-Lee'],
      en: ['Tim Berners-Lee', 'British computer scientist who invented the World Wide Web while working at CERN.', 'https://en.wikipedia.org/wiki/Tim_Berners-Lee']
    },
    'edward-curtis': {
      fr: ['Edward S. Curtis', 'Photographe et ethnologue américain connu pour son vaste travail documentaire sur de nombreux peuples autochtones d’Amérique du Nord.', 'https://fr.wikipedia.org/wiki/Edward_Sheriff_Curtis'],
      en: ['Edward S. Curtis', 'American photographer and ethnologist known for his extensive documentation of many Indigenous peoples of North America.', 'https://en.wikipedia.org/wiki/Edward_S._Curtis']
    },
    'brave-new-world': {
      fr: ['Le Meilleur des mondes', 'Roman dystopique d’Aldous Huxley publié en 1932, décrivant une société technologiquement organisée autour du conditionnement et du contrôle social.', 'https://fr.wikipedia.org/wiki/Le_Meilleur_des_mondes'],
      en: ['Brave New World', 'Aldous Huxley’s 1932 dystopian novel depicting a technologically organized society built around conditioning and social control.', 'https://en.wikipedia.org/wiki/Brave_New_World']
    },
    'this-perfect-day': {
      fr: ['Un bonheur insoutenable', 'Roman dystopique d’Ira Levin publié en 1970, décrivant une société mondiale administrée par un système informatique central.', 'https://fr.wikipedia.org/wiki/Un_bonheur_insoutenable'],
      en: ['This Perfect Day', 'Ira Levin’s 1970 dystopian novel depicting a world society administered by a central computer system.', 'https://en.wikipedia.org/wiki/This_Perfect_Day']
    },
    'purgatorius': {
  fr: [
    'Purgatorius',
    'Genre fossile de petits mammifères du Paléocène, considéré comme proche des premiers primates. Ses fossiles sont connus en Amérique du Nord après la limite Crétacé-Paléogène.',
    'https://fr.wikipedia.org/wiki/Purgatorius'
  ],
  en: [
    'Purgatorius',
    'An extinct genus of small Paleocene mammals generally considered close to the earliest primates. Its fossils are known from North America after the Cretaceous-Paleogene boundary.',
    'https://en.wikipedia.org/wiki/Purgatorius'
  ]
},

'nuclear-winter': {
  fr: [
    'Hiver nucléaire',
    'Refroidissement climatique hypothétique pouvant résulter d’une guerre nucléaire majeure, lorsque d’importantes quantités de fumées et de particules réduisent la lumière solaire atteignant la surface terrestre.',
    'https://fr.wikipedia.org/wiki/Hiver_nucl%C3%A9aire'
  ],
  en: [
    'Nuclear winter',
    'A hypothetical period of severe cooling that could follow a large-scale nuclear war, when extensive smoke and particles reduce the sunlight reaching Earth’s surface.',
    'https://en.wikipedia.org/wiki/Nuclear_winter'
  ]
},

'dinosaurs': {
  fr: [
    'Dinosaures',
    'Groupe de reptiles appartenant au clade Dinosauria, apparu au Trias et ayant dominé de nombreux écosystèmes terrestres pendant l’ère Mésozoïque. Les oiseaux sont les seuls dinosaures actuellement vivants.',
    'https://fr.wikipedia.org/wiki/Dinosauria'
  ],
  en: [
    'Dinosaurs',
    'A group of reptiles belonging to the clade Dinosauria, which appeared during the Triassic and dominated many terrestrial ecosystems during the Mesozoic. Birds are the only dinosaurs alive today.',
    'https://en.wikipedia.org/wiki/Dinosaur'
  ]
},

'biospheric': {
  fr: [
    'Biosphérique',
    'Qui concerne la biosphère : l’ensemble des êtres vivants, des milieux où la vie existe sur Terre et de leurs interactions.',
    'https://fr.wikipedia.org/wiki/Biosph%C3%A8re'
  ],
  en: [
    'Biospheric',
    'Relating to the biosphere: all living beings, the environments where life exists on Earth, and their interactions.',
    'https://en.wikipedia.org/wiki/Biosphere'
  ]
},

'invariant': {
  fr: [
    'Invariant',
    'Élément qui demeure stable lorsque le contexte ou le point de vue change. Ici, il désigne l’idée essentielle préservée par chaque capsule.',
    'https://fr.wikipedia.org/wiki/Invariant'
  ],
  en: [
    'Invariant',
    'An element that remains stable when the context or viewpoint changes. Here it means the essential idea preserved by each capsule.',
    'https://en.wikipedia.org/wiki/Invariant_(mathematics)'
  ]
},

'reality': {
  fr: [
    'Réel',
    'Ce qui existe et agit indépendamment de nos représentations : corps, matières, milieux, relations et contraintes physiques du monde.',
    'https://fr.wikipedia.org/wiki/R%C3%A9alit%C3%A9'
  ],
  en: [
    'Reality',
    'What exists and acts independently of our representations: bodies, matter, environments, relationships and physical constraints.',
    'https://en.wikipedia.org/wiki/Reality'
  ]
},

'birds': {
  fr: [
    'Oiseaux',
    'Vertébrés à plumes appartenant au groupe des dinosaures aviens. Les oiseaux actuels représentent la seule lignée de dinosaures ayant survécu à l’extinction de la fin du Crétacé.',
    'https://fr.wikipedia.org/wiki/Oiseau'
  ],
  en: [
    'Birds',
    'Feathered vertebrates belonging to avian dinosaurs. Modern birds are the only dinosaur lineage that survived the end-Cretaceous mass extinction.',
    'https://en.wikipedia.org/wiki/Bird'
  ]
},
  };

  function getEntry(id) {
    const item = D[id];
    return item ? (isEnglish ? item.en : item.fr) : null;
  }

  function ensureDialog() {
    let dialog = document.getElementById('seed-definition-dialog');
    if (dialog) return dialog;
    dialog = document.createElement('dialog');
    dialog.id = 'seed-definition-dialog';
    dialog.className = 'seed-definition-dialog';
    dialog.setAttribute('aria-labelledby', 'seed-definition-title');
    dialog.innerHTML = `
      <div class="seed-definition-dialog__inner">
        <button type="button" class="seed-definition-dialog__close" aria-label="${isEnglish ? 'Close definition' : 'Fermer la définition'}">×</button>
        <p class="seed-definition-dialog__eyebrow">${isEnglish ? 'Definition' : 'Définition'}</p>
        <h3 id="seed-definition-title"></h3>
        <p id="seed-definition-text"></p>
        <a id="seed-definition-link" href="#" target="_blank" rel="noopener noreferrer">${isEnglish ? 'Learn more' : 'En savoir plus'} <span aria-hidden="true">↗</span></a>
      </div>`;
    document.body.appendChild(dialog);
    return dialog;
  }

  let trigger = null;

  function closeDialog(dialog) {
    if (typeof dialog.close === 'function' && dialog.open) dialog.close();
    else dialog.removeAttribute('open');
    if (trigger && document.contains(trigger)) trigger.focus({preventScroll:true});
  }

  document.addEventListener('click', function (event) {
    const term = event.target.closest('[data-seed-definition]');
    if (term) {
      const entry = getEntry(term.dataset.seedDefinition);
      if (!entry) return;
      event.preventDefault();
      trigger = term;
      const dialog = ensureDialog();
      dialog.querySelector('#seed-definition-title').textContent = entry[0];
      dialog.querySelector('#seed-definition-text').textContent = entry[1];
      dialog.querySelector('#seed-definition-link').href = entry[2];
      if (typeof dialog.showModal === 'function') dialog.showModal();
      else dialog.setAttribute('open', '');
      requestAnimationFrame(() => dialog.querySelector('.seed-definition-dialog__close').focus({preventScroll:true}));
      return;
    }

    const close = event.target.closest('.seed-definition-dialog__close');
    if (close) {
      closeDialog(close.closest('dialog'));
      return;
    }

    const dialog = event.target.closest('#seed-definition-dialog');
    if (dialog && event.target === dialog) closeDialog(dialog);
  });

  document.addEventListener('cancel', function (event) {
    if (event.target && event.target.id === 'seed-definition-dialog') {
      event.preventDefault();
      closeDialog(event.target);
    }
  }, true);
})();
