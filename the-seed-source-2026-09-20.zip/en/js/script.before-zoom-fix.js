function toggleAudio() {
    var video = document.getElementById("veoVideo");
    var btn = document.querySelector(".audio-control-btn");
    
    if (video.muted) {
        video.muted = false;
        btn.innerHTML = "🔇 Couper le son";
    } else {
        video.muted = true;
        btn.innerHTML = "🔊 Activer le son";
    }
}

// Chargement et injection asynchrone des composants (Header / Footer)
fetch('/header.html')
.then(r => r.text())
.then(data => document.getElementById('header').innerHTML = data)
.catch(()=>{});

fetch('/footer.html')
.then(r => r.text())
.then(data => document.getElementById('footer').innerHTML = data)
.catch(()=>{});

// =========================================================
// ZOOM DES IMAGES
// =========================================================

document.addEventListener('DOMContentLoaded', () => {
  const images = document.querySelectorAll(
    '.container img:not([src*="ACCUEIL"]), main.container img:not([src*="ACCUEIL"])'
  );

  images.forEach((img) => {
    // Empêche la création de plusieurs wrappers si le script est chargé deux fois
    if (img.closest('.img-flux-wrapper')) return;

    const wrapper = document.createElement('div');
    wrapper.className = 'img-flux-wrapper';

    img.parentNode.insertBefore(wrapper, img);
    wrapper.appendChild(img);

    img.addEventListener('click', (event) => {
      event.stopPropagation();

      document.querySelectorAll('.img-flux-wrapper.active').forEach((other) => {
        if (other !== wrapper) {
          other.classList.remove('active');
        }
      });

      wrapper.classList.toggle('active');
    });
  });

  // Ferme le zoom en cliquant ailleurs dans la page
  document.addEventListener('click', () => {
    document.querySelectorAll('.img-flux-wrapper.active').forEach((wrapper) => {
      wrapper.classList.remove('active');
    });
  });
});


// =========================================================
// LETTRINES AUTOMATIQUES
// Syntaxe : [I]l y a longtemps...
// =========================================================

document.addEventListener('DOMContentLoaded', () => {
  const elements = document.querySelectorAll(
    '.container p, .container h2, .container h3, .container h4, .container h5, .container h6'
  );

  const pattern = /^\s*\[([A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF])\]/;

  elements.forEach((element) => {
    if (element.querySelector('.lettrine')) return;

    const match = element.textContent.match(pattern);
    if (!match) return;

    const letter = match[1];
    const htmlPattern = /^\s*\[[A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF]\]/;

    element.innerHTML = element.innerHTML.replace(
      htmlPattern,
      `<span class="lettrine">${letter}</span>`
    );
  });
});

