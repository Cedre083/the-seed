document.addEventListener("DOMContentLoaded", function () {

    const slide = document.getElementById("seed-slide");
    const closeBtn = document.getElementById("seed-close");

    if (!slide || !closeBtn) return;

    const showDelay = 80000;     // 80 secondes
    const holdDuration = 10000;   // 10 secondes

    // Apparition : zoom manuel en JS (lent et fluide)
    setTimeout(() => {

        slide.style.opacity = "1"; // devient visible

        let scale = 0.05;
        const target = 1;
        const step = 0.008; // zoom lent

        const zoomIn = setInterval(() => {
            scale += step;

            slide.style.transform = `translate(-50%, -50%) scale(${scale})`;

            if (scale >= target) {
                slide.style.transform = `translate(-50%, -50%) scale(1)`;
                clearInterval(zoomIn);
            }
        }, 16); // 60 FPS
    }, showDelay);

    // Disparition douce
    setTimeout(() => hideSlide(), showDelay + holdDuration + 1000);

    closeBtn.addEventListener("click", hideSlide);

    function hideSlide() {

        // Fondu doux (3 secondes)
        slide.style.opacity = "0";

        // Après le fondu, on réduit la taille
        setTimeout(() => {
            slide.style.transform = "translate(-50%, -50%) scale(0.05)";
        }, 8000); // correspond à la durée du fondu CSS
    }
});
