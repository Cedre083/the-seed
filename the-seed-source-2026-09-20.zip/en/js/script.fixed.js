function toggleAudio() {
  const video = document.getElementById("veoVideo");
  const btn = document.querySelector(".audio-control-btn");
  if (!video || !btn) return;

  video.muted = !video.muted;
  btn.textContent = video.muted ? "🔊 Activer le son" : "🔇 Couper le son";
}

// Chargement des composants communs
fetch("/header.html")
  .then((response) => {
    if (!response.ok) throw new Error(`Header: HTTP ${response.status}`);
    return response.text();
  })
  .then((html) => {
    const header = document.getElementById("header");
    if (header) header.innerHTML = html;
  })
  .catch(() => {});

fetch("/footer.html")
  .then((response) => {
    if (!response.ok) throw new Error(`Footer: HTTP ${response.status}`);
    return response.text();
  })
  .then((html) => {
    const footer = document.getElementById("footer");
    if (footer) footer.innerHTML = html;
  })
  .catch(() => {});

// =========================================================
// ZOOM DES IMAGES — toutes les pages
// =========================================================

document.addEventListener("DOMContentLoaded", () => {
  const images = document.querySelectorAll(
    "main img:not([src*='ACCUEIL']):not([data-no-zoom]), .container img:not([src*='ACCUEIL']):not([data-no-zoom])"
  );

  images.forEach((img) => {
    if (img.closest(".img-flux-wrapper")) return;

    const wrapper = document.createElement("div");
    wrapper.className = "img-flux-wrapper";
    img.parentNode.insertBefore(wrapper, img);
    wrapper.appendChild(img);

    img.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();

      document.querySelectorAll(".img-flux-wrapper.active").forEach((other) => {
        if (other !== wrapper) other.classList.remove("active");
      });

      wrapper.classList.toggle("active");
    });
  });

  document.addEventListener("click", () => {
    document.querySelectorAll(".img-flux-wrapper.active").forEach((wrapper) => {
      wrapper.classList.remove("active");
    });
  });
});

// =========================================================
// LETTRINES AUTOMATIQUES — syntaxe : [I]l y a...
// =========================================================

document.addEventListener("DOMContentLoaded", () => {
  const elements = document.querySelectorAll(
    "main p, main h1, main h2, main h3, main h4, main h5, main h6"
  );
  const letterPattern = /^\s*\[([A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF])\]/;

  elements.forEach((element) => {
    if (element.querySelector(".lettrine")) return;

    const match = element.textContent.match(letterPattern);
    if (!match) return;

    const htmlPattern = /^\s*\[[A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF]\]/;
    element.innerHTML = element.innerHTML.replace(
      htmlPattern,
      `<span class="lettrine">${match[1]}</span>`
    );
  });
});

// Permet au bouton audio d’être appelé depuis un attribut HTML onclick.
window.toggleAudio = toggleAudio;

