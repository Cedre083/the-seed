function toggleAudio() {
  const video = document.getElementById("veoVideo");
  const btn = document.querySelector(".audio-control-btn");
  if (!video || !btn) return;

  video.muted = !video.muted;
  btn.textContent = video.muted ? "🔊 Activer le son" : "🔇 Couper le son";
}

// Charge Sylva uniquement après l'injection du footer commun.
function loadSylvaScript() {
  if (document.querySelector('script[data-sylva-script]')) return;
  const script = document.createElement('script');
  script.src = '/js/sylva.js?v=20260912-5';
  script.defer = true;
  script.dataset.sylvaScript = 'true';
  document.body.appendChild(script);
}

// Chargement des composants communs
fetch("/header.html")
  .then((response) => {
    if (!response.ok) throw new Error(`Header: HTTP ${response.status}`);
    return response.text();
  })
  .then((html) => {
    const header = document.getElementById("header");
    if (header) header.innerHTML = html;
  })
  .catch(() => {});

fetch("/footer.html")
  .then((response) => {
    if (!response.ok) throw new Error(`Footer: HTTP ${response.status}`);
    return response.text();
  })
  .then((html) => {
    const footer = document.getElementById("footer");
    if (footer) {
      footer.innerHTML = html;
      loadSylvaScript();
    }
  })
  .catch(() => {});

// =========================================================
// NAVIGATION — V6 : menus exclusifs + trigramme mobile
// =========================================================

function closeHeaderSubmenus(header, exceptMenu = null) {
  header.querySelectorAll("details.nav-menu[open]").forEach((menu) => {
    if (menu !== exceptMenu) menu.removeAttribute("open");
  });
}

function closeMobileNavigation(header) {
  const nav = header.querySelector(".nav");
  const toggle = header.querySelector(".mobile-menu-toggle");
  if (!nav || !toggle) return;
  nav.classList.remove("is-open");
  toggle.setAttribute("aria-expanded", "false");
  closeHeaderSubmenus(header);
}

document.addEventListener("click", (event) => {
  const header = document.getElementById("header");
  if (!header) return;

  const toggle = event.target.closest(".mobile-menu-toggle");
  if (toggle && header.contains(toggle)) {
    const nav = header.querySelector(".nav");
    if (!nav) return;
    const opening = !nav.classList.contains("is-open");
    nav.classList.toggle("is-open", opening);
    toggle.setAttribute("aria-expanded", opening ? "true" : "false");
    toggle.setAttribute("aria-label", opening ? "Fermer le menu" : "Ouvrir le menu");
    if (!opening) closeHeaderSubmenus(header);
    return;
  }

  const clickedSummary = event.target.closest("details.nav-menu > summary");
  if (clickedSummary && header.contains(clickedSummary)) {
    closeHeaderSubmenus(header, clickedSummary.parentElement);
    return;
  }

  const clickedNavLink = event.target.closest("#header .nav a");
  if (clickedNavLink) {
    closeHeaderSubmenus(header);
    if (window.matchMedia("(max-width: 48rem)").matches) closeMobileNavigation(header);
    return;
  }

  if (!event.target.closest("#header .site-header")) {
    closeHeaderSubmenus(header);
    if (window.matchMedia("(max-width: 48rem)").matches) closeMobileNavigation(header);
  }
});

window.addEventListener("resize", () => {
  if (!window.matchMedia("(max-width: 48rem)").matches) {
    const header = document.getElementById("header");
    if (!header) return;
    const nav = header.querySelector(".nav");
    const toggle = header.querySelector(".mobile-menu-toggle");
    if (nav) nav.classList.remove("is-open");
    if (toggle) toggle.setAttribute("aria-expanded", "false");
  }
});

// =========================================================
// ZOOM DES IMAGES — toutes les pages
// =========================================================

document.addEventListener("DOMContentLoaded", () => {
  const images = document.querySelectorAll(
    "main img:not([src*='ACCUEIL']):not([data-no-zoom]), .container img:not([src*='ACCUEIL']):not([data-no-zoom])"
  );

  images.forEach((img) => {
    if (img.closest(".img-flux-wrapper")) return;

    const wrapper = document.createElement("div");
    wrapper.className = "img-flux-wrapper";
    img.parentNode.insertBefore(wrapper, img);
    wrapper.appendChild(img);

    img.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();

      document.querySelectorAll(".img-flux-wrapper.active").forEach((other) => {
        if (other !== wrapper) other.classList.remove("active");
      });

      wrapper.classList.toggle("active");
    });
  });

  document.addEventListener("click", () => {
    document.querySelectorAll(".img-flux-wrapper.active").forEach((wrapper) => {
      wrapper.classList.remove("active");
    });
  });
});

// =========================================================
// LETTRINES AUTOMATIQUES — syntaxe : [I]l y a...
// =========================================================

document.addEventListener("DOMContentLoaded", () => {
  const elements = document.querySelectorAll(
    "main p, main h1, main h2, main h3, main h4, main h5, main h6"
  );
  const letterPattern = /^\s*\[([A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF])\]/;

  elements.forEach((element) => {
    if (element.querySelector(".lettrine")) return;

    const match = element.textContent.match(letterPattern);
    if (!match) return;

    const htmlPattern = /^\s*\[[A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF]\]/;
    element.innerHTML = element.innerHTML.replace(
      htmlPattern,
      `<span class="lettrine">${match[1]}</span>`
    );
  });
});


// =========================================================
// SOMMAIRES DE PAGE — V11 : fermeture après sélection
// =========================================================

// Explicit toggle: keeps the contents working if another page component
// interferes with the browser's native <details> behaviour.
document.addEventListener("click", (event) => {
  const tocSummary = event.target.closest("details.page-toc > summary.page-toc__title");
  if (!tocSummary) return;

  const toc = tocSummary.parentElement;
  if (!toc || !toc.classList.contains("page-toc")) return;

  event.preventDefault();
  toc.open = !toc.open;
});

document.addEventListener("click", (event) => {
  const tocLink = event.target.closest(".page-toc__list a[href^='#']");
  if (!tocLink) return;

  const toc = tocLink.closest("details.page-toc");
  if (toc) toc.removeAttribute("open");
});

// Permet au bouton audio d’être appelé depuis un attribut HTML onclick.
window.toggleAudio = toggleAudio;


// =========================================================
// RETOUR AU SOMMAIRE — V13 : position précise sous le header
// =========================================================

document.addEventListener("click", (event) => {
  const backLink = event.target.closest(".heading-back-to-toc[href='#sommaire']");
  if (!backLink) return;

  const toc = document.getElementById("sommaire");
  if (!toc) return;

  event.preventDefault();

  const header = document.getElementById("header");
  const headerHeight = header ? header.getBoundingClientRect().height : 0;
  const gap = window.matchMedia("(max-width: 48rem)").matches ? 6 : 8;
  const top = toc.getBoundingClientRect().top + window.scrollY - headerHeight - gap;
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  window.scrollTo({
    top: Math.max(0, top),
    behavior: reducedMotion ? "auto" : "smooth"
  });

  if (history.replaceState) history.replaceState(null, "", "#sommaire");
});

/*
  À ajouter à la fin de /js/script.js.
  Le MP4 est chargé uniquement après le clic sur la vignette.
*/

(function () {
  function initialiseFilmPlayers() {
    document.querySelectorAll('[data-video-player]').forEach((player) => {
      if (player.dataset.initialised === 'true') return;

      const trigger = player.querySelector('.film-flux__vignette');
      const video = player.querySelector('.film-flux__video');
      const source = video ? video.querySelector('source[data-src]') : null;

      if (!trigger || !video || !source) return;
      player.dataset.initialised = 'true';

      trigger.addEventListener('click', () => {
        // Le lien du MP4 est affecté ici, jamais avant le clic.
        source.src = source.dataset.src;

        // Le bouton est retiré du rendu ; le lecteur occupe alors sa place.
        trigger.setAttribute('hidden', '');
        video.removeAttribute('hidden');
        video.load();

        // Cette action provient d'un clic utilisateur : la lecture peut démarrer.
        video.play().catch(() => {
          // Les contrôles restent visibles si le navigateur attend une nouvelle action.
        });
      }, { once: true });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiseFilmPlayers);
  } else {
    initialiseFilmPlayers();
  }
}());
