(() => {
  'use strict';

  const STORAGE_KEY = 'theSeedPrivacyNoticeV3';
  const isEnglish = (document.documentElement.lang || '').toLowerCase().startsWith('en') || location.pathname.includes('/en/');

  const text = isEnglish ? {
    title: 'Privacy & GDPR',
    message: 'This website complies with the <a class="seed-privacy-inline-policy" href="/politique-de-confidentialite.html">GDPR</a>. It contains no cookies and therefore does not appropriate any of your personal data.',
    help: 'Thank you for helping us',
    understand: 'I understand',
    reopen: 'Privacy'
  } : {
    title: 'Confidentialité & RGPD',
    message: 'Ce site WEB est conforme au <a class="seed-privacy-inline-policy" href="/politique-de-confidentialite.html">RGPD</a>.  Il ne contient aucun cookie, aucune publicité et ne s’approprie donc pas la moindre de vos données personnelles.',
    help: 'Merci de nous aider',
    understand: 'J\u2019ai compris',
    reopen: 'Confidentialité'
  };

  function installStyles() {
    if (document.getElementById('seed-privacy-styles')) return;
    const style = document.createElement('style');
    style.id = 'seed-privacy-styles';
    style.textContent = `
      .seed-privacy-banner {
        position: fixed;
        left: 50%;
        bottom: 1rem;
        transform: translateX(-50%);
        z-index: 2147483000;
        width: min(56rem, calc(100% - 2rem));
        box-sizing: border-box;
        padding: 1.15rem 1.25rem;
        border: 1px solid rgba(255,255,255,.22);
        border-radius: .9rem;
        background: rgba(10,15,13,.97);
        color: #f3e7a2;
        box-shadow: 0 .6rem 2rem rgba(0,0,0,.38);
        font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        text-align: center;
      }
      .seed-privacy-banner[hidden] { display: none !important; }
      .seed-privacy-banner h2 {
        margin: 0 0 .55rem;
        padding: 0;
        color: #f3e7a2;
        font-size: 1.08rem;
        line-height: 1.4;
        letter-spacing: 0;
        text-align: center;
      }
      .seed-privacy-banner p {
        margin: 0;
        color: #f3e7a2;
        font-size: .97rem;
        line-height: 1.55;
        text-align: center;
      }
      .seed-privacy-links {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: .55rem 1rem;
        margin-top: .8rem;
      }
      .seed-privacy-banner .seed-privacy-inline-policy,
      .seed-privacy-links a {
        color: #f3e7a2 !important;
        font-size: .9rem;
        line-height: 1.35;
        text-decoration: underline;
        text-underline-offset: .18em;
      }
      .seed-privacy-links .seed-privacy-help {
        font-style: italic;
      }
      .seed-privacy-banner .seed-privacy-inline-policy:hover,
      .seed-privacy-banner .seed-privacy-inline-policy:focus-visible,
      .seed-privacy-links a:hover,
      .seed-privacy-links a:focus-visible {
        color: #fff4b8 !important;
        outline: 2px solid rgba(255,255,255,.8);
        outline-offset: 3px;
        border-radius: .2rem;
      }
      .seed-privacy-actions {
        display: flex;
        justify-content: center;
        margin-top: .9rem;
      }
      .seed-privacy-actions button {
        box-sizing: border-box;
        min-height: 2.7rem;
        padding: .62rem 1.1rem;
        border: 1px solid #98a99b;
        border-radius: .55rem;
        background: #dce7de;
        color: #172019;
        font: inherit;
        font-size: .9rem;
        line-height: 1.2;
        font-weight: 700;
      }
      .seed-privacy-actions button:hover,
      .seed-privacy-actions button:focus-visible {
        outline: 2px solid #ffffff;
        outline-offset: 2px;
      }
      .seed-privacy-reopen {
        position: fixed;
        left: .75rem;
        bottom: .75rem;
        z-index: 2147482999;
        border: 1px solid rgba(255,255,255,.22);
        border-radius: 999px;
        padding: .45rem .7rem;
        background: rgba(10,15,13,.88);
        color: #d7ddd8;
        font: 600 .72rem/1.2 Inter, system-ui, sans-serif;
        opacity: .72;
      }
      .seed-privacy-reopen:hover,
      .seed-privacy-reopen:focus-visible {
        opacity: 1;
        outline: 2px solid #fff;
        outline-offset: 2px;
      }
      @media (max-width: 600px) {
        .seed-privacy-banner {
          bottom: .6rem;
          width: calc(100% - 1.2rem);
          max-height: min(72dvh, 32rem);
          overflow-y: auto;
          overscroll-behavior: contain;
          -webkit-overflow-scrolling: touch;
          padding: 1rem;
        }
        .seed-privacy-links {
          flex-direction: column;
          align-items: center;
          gap: .55rem;
        }
        .seed-privacy-actions button { width: 100%; }
      }
      @media print {
        .seed-privacy-banner,
        .seed-privacy-reopen { display: none !important; }
      }
    `;
    document.head.appendChild(style);
  }

  function setSeen() {
    try { localStorage.setItem(STORAGE_KEY, 'seen'); } catch (_) {}
  }

  function wasSeen() {
    try { return localStorage.getItem(STORAGE_KEY) === 'seen'; } catch (_) { return false; }
  }

  function createUI() {
    if (document.getElementById('seed-privacy-banner')) return;

    installStyles();

    const banner = document.createElement('aside');
    banner.id = 'seed-privacy-banner';
    banner.className = 'seed-privacy-banner';
    banner.setAttribute('role', 'dialog');
    banner.setAttribute('aria-modal', 'false');
    banner.setAttribute('aria-labelledby', 'seed-privacy-title');
    banner.innerHTML = `
      <h2 id="seed-privacy-title">${text.title}</h2>
      <p>${text.message}</p>
      <div class="seed-privacy-links">
        <a class="seed-privacy-help" href="#soutenir">${text.help}</a>
      </div>
      <div class="seed-privacy-actions">
        <button type="button" data-seed-privacy-understand>${text.understand}</button>
      </div>
    `;

    const reopen = document.createElement('button');
    reopen.type = 'button';
    reopen.className = 'seed-privacy-reopen';
    reopen.textContent = text.reopen;
    reopen.setAttribute('aria-controls', 'seed-privacy-banner');
    reopen.setAttribute('aria-expanded', 'false');

    document.body.appendChild(banner);
    document.body.appendChild(reopen);

    const understand = banner.querySelector('[data-seed-privacy-understand]');
    understand.addEventListener('click', () => {
      setSeen();
      banner.hidden = true;
      reopen.setAttribute('aria-expanded', 'false');
    });

    const supportLink = banner.querySelector('.seed-privacy-help');
    supportLink.addEventListener('click', (event) => {
      const target = document.getElementById('soutenir');
      if (target) {
        event.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });

    reopen.addEventListener('click', () => {
      banner.hidden = false;
      reopen.setAttribute('aria-expanded', 'true');
      understand.focus();
    });

    if (wasSeen()) {
      banner.hidden = true;
    } else {
      reopen.setAttribute('aria-expanded', 'true');
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createUI, { once: true });
  } else {
    createUI();
  }
})();
