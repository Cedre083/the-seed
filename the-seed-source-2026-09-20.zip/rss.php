<?php
declare(strict_types=1);

// Flux statiques canoniques : ils fonctionnent même sans réécriture serveur.
$language = isset($_GET['lang']) && $_GET['lang'] === 'en' ? 'en' : 'fr';
$target = $language === 'en' ? '/en/rss.xml' : '/rss.xml';
header('Cache-Control: public, max-age=3600');
header('Location: ' . $target, true, 302);
exit;
